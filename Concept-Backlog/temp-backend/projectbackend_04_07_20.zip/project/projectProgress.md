# 02-10-20
    * Learned the syntax of Mongodb.
    * Created a rough of the necessary tables for the Event website.


# 03-19-20
    * Created MongoDB Server using MongoDB Atlas.
    * Connected the MongoDB server to local host using express
    * Added, Deleted, and Pulled Data from Mongo server using Postman to perform GET POST and Delete Requests.
    * Created temporary structure for the 'users' within the website

# 04-05-2020
    * Created the client side "front end connection" using react. 
    * Created a way for the react front end and the express back end to run at the same time using concurrently.
    * Using bootstrap and reactstrap created a navbar on the website that will be pivitol to navigating through the website. 

## Brain Notes
    * Potential Deployment : Heroku
    * npm run client-install should be used when using a version from gethub to install the client dependencies.
    * Next step is finding a way to put multiple pages on the website through react and properly being able to navigate through them.
    * Next Step, Connecting express/mongo backend to front end.