module.exports = {
    mongoURI: 'mongodb+srv://rross16:Towson123@mern-project-x55c1.mongodb.net/test?retryWrites=true&w=majority'
}