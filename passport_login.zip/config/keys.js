dbPassword = 'mongodb+srv://mongoUser0:'+ encodeURIComponent('zidzu0-teqtew-dewwIk') + '@mycluster0-5fmrd.mongodb.net/test?retryWrites=true';

module.exports = {
    mongoURI: dbPassword
};