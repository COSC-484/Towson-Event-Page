module.exports = {
    mongoURI: 'mongodb+srv://rross16:Grafixxz21!!@mern-project-x55c1.mongodb.net/test?retryWrites=true&w=majority'
}